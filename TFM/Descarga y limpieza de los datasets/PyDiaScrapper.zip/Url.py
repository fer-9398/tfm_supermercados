class URL:
	SITEMAP = 'https://www.dia.es/compra-online/sitemap.xml'