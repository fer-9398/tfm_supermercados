import requests
from Url import URL

class Sitemap:
	def fetchSitemap():
		response = requests.get(URL.SITEMAP).text
		return response