
from Categories import Categories
import json

def jsonParser(data):
	return json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False).encode('utf8').decode('utf8')

def init():
	logo = """
																																								
																																								
                        D I A  S C R A P P E R																										
																																								
																																								
      %%%%%%%%%%%%#       %%%%*                           .%%##############     
      %%%%%%%%%%%%%%%%.                                 ( %%%%%    %%%%%, (     
      %%%%%/      %%%%%%  %%%%*   /%%%%%%%%%%%%%        % %%%%%# %%%%%%   (     
      %%%%%/       #%%%%  %%%%* #%%%%%/ .%%%%%%%        %      #%%%%%     (     
      %%%%%/       #%%%%  %%%%* %%%%       #%%%%        %    *%%%%%       (     
      %%%%%/      %%%%%#  %%%%* %%%%%      %%%%%        %   %%%%%, %%%%%% (     
      %%%%%%%%%%%%%%%%    %%%%*  %%%%%%%%%%%%%%%        % %%%%%#   (%%%%./      
      %%%%%%%%%%(.        %%%%*      #%%%%/,####        %%%%%%%%%%%%%%%/        
                                                                                
	"""
	print(logo)
	print("\n")
	print("Avoid entering more than 10 categories :)")
	print("\n")
	print("========================================================")
	print("\n")
	print("\n")
	cat_number = int(input("Enter number of categories (Default 5): ") or "5")
	filename = (input("Enter file name: ") or "products")+(".json")
	print("\n")
	print("Retrieving categories...")
	sl = slice(cat_number)
	categories = Categories.getCategoriesURLs()[sl]
	scrapped = []
	for category in categories:
		products = Categories.scrapCategory(category, scrapped)
		scrapped.extend(products)
	open(filename, "w").write(jsonParser(scrapped))
	print("\n")
	print("File saved as " + filename)

init()
