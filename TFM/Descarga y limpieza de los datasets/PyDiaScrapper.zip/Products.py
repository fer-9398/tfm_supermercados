import re
from Sitemap import Sitemap

class Products:
	def getProductsURLs():
		sitemap = Sitemap.fetchSitemap()
		regexp = "<loc>(https:\/\/.*?\/p\/.*?)<\/loc>"
		return re.findall(regexp, sitemap)

