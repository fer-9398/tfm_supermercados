import re
import requests
import json
from Sitemap import Sitemap
from bs4 import BeautifulSoup

class Categories:
	def getCategoriesURLs():
		sitemap = Sitemap.fetchSitemap()
		regexp = "<loc>(https:\/\/.*?\/cf)<\/loc>"
		return re.findall(regexp, sitemap)
	
		scrappedProducts = []
	def scrapCategory(categoryURL, scrappedProducts = []):
		print("\n")
		print("Retrieving products from " + categoryURL)
		print("========================================================")
		response = requests.get(categoryURL)
		soup = BeautifulSoup(response.content, 'html.parser')
		products = soup.select('.product-list__item')
		for product in products:
			anchor = product.select('a')[0]
			price_container = product.select('.price_container')[0]
			title = anchor.get('title')
			print("Retrieving product: " + title)
			href = anchor.get('href')
			price = price_container.select('p')[0].text.replace('\n', '').replace('\t', '').replace('\r', '').replace(u'\xa0', u' ')
			priceAvg = price_container.select('p')[1].text.replace('\n', '').replace('\t', '').replace('\r', '').replace(u'\xa0', u' ')
			scrappedProducts.append({'title': title, 'href': href, 'price': price, 'priceAvg': priceAvg})
		print("========================================================")
		print("\n")
		return scrappedProducts